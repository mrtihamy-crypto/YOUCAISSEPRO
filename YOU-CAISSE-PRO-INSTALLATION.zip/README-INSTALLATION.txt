﻿================================================================
    YOU CAISSE PRO - Application de Caisse Professionnelle
================================================================

INSTALLATION RAPIDE
===================

1. Decompressez ce dossier ou vous voulez
2. Double-cliquez sur DEMARRER.bat
3. L'application s'ouvre dans votre navigateur
4. Connectez-vous avec admin / admin123

UTILISATION
===========

DEMARRER.bat  : Lance l'application
ARRETER.bat   : Arrete les serveurs

IMPORTANT : Ne fermez pas les fenetres Backend et Frontend !

SUPPORT
=======

Email : support@youcaisse.pro

================================================================
