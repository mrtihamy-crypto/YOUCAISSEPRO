﻿================================================================
    YOU CAISSE PRO - Application Executable Windows
================================================================

INSTALLATION
============

1. Decompressez ce dossier ou vous voulez
2. Double-cliquez sur DEMARRER.bat
3. L'application demarre automatiquement

FICHIERS
========

YOU-CAISSE-Backend.exe  : Serveur API (port 3001)
YOU-CAISSE-Frontend.exe : Interface Web (port 5173)
DEMARRER.bat           : Lance l'application
ARRETER.bat            : Arrete l'application
database.sqlite        : Base de donnees
frontend-dist/         : Fichiers de l'interface

CONNEXION
=========

Admin     : admin / admin123
Caissier  : caissier / caissier123
Serveur   : serveur / serveur123
Reception : reception / reception123

RESEAU (pour tablettes)
=======================

Sur les tablettes, ouvrez: http://[IP_DU_PC]:5173
Exemple: http://192.168.1.100:5173

NOTES
=====

- Aucune installation de Node.js requise
- Les .exe contiennent tout le necessaire
- Fonctionne sur Windows 7, 8, 10, 11
- Taille totale: ~100 MB

================================================================
