export {};
//# sourceMappingURL=migrate-reception.d.ts.map