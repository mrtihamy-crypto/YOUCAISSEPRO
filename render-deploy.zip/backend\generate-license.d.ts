export {};
//# sourceMappingURL=generate-license.d.ts.map