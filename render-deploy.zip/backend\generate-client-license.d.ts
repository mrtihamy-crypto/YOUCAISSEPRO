export {};
//# sourceMappingURL=generate-client-license.d.ts.map