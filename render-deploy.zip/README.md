# 🚀 DEPLOIEMENT SUR RENDER - SANS GITHUB

## ✅ ETAPE 1 : Préparer les fichiers

Les fichiers sont prêts dans le dossier `render-deploy/` :
- ✓ `server.js` - Serveur unifié
- ✓ `Dockerfile` - Configuration Docker
- ✓ `package.json` - Dépendances
- ✓ `backend/` - API compilée
- ✓ `frontend/` - Interface compilée

---

## 📋 ETAPE 2 : Créer la Base de Données PostgreSQL

1. Allez sur https://dashboard.render.com
2. Connectez-vous ou créez un compte (gratuit)
3. Cliquez **"New +"** → **"PostgreSQL"**
4. Configurez :
   ```
   Name: you-caisse-db
   Database: youcaisse
   Region: Frankfurt
   Plan: Free
   ```
5. Cliquez **"Create Database"**
6. ⏱️ **ATTENDEZ 2-3 MINUTES**

**Une fois créée :**
- 📌 **COPIEZ L'URL complète** (commence par `postgresql://`)
- Cette URL sera votre `DATABASE_URL`

---

## 🐳 ETAPE 3 : Créer un Web Service Docker

### Option A : Déployer depuis ce dossier (le plus simple)

1. **Préparez les fichiers** :
   ```powershell
   cd "c:\Users\mrtih\Desktop\YOU CAISSE PRO\render-deploy"
   git init
   git add .
   git commit -m "Initial commit"
   ```

2. Sur **Render** :
   - Cliquez **"New +"** → **"Web Service"**
   - Choisissez **"Build and deploy from Git repository"**
   - Entrez l'URL locale de votre repo
   - Ou uploadez manuellement les fichiers

### Option B : Déployer depuis GitHub (recommandé)

1. Créez un nouveau repo GitHub privé : `YOUCAISSEPRO-RENDER`
2. Poussez le contenu du dossier `render-deploy/` :
   ```powershell
   cd "c:\Users\mrtih\Desktop\YOU CAISSE PRO\render-deploy"
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/mrtihamy-crypto/YOUCAISSEPRO-RENDER
   git push -u origin main
   ```

3. Sur **Render** :
   - Cliquez **"New +"** → **"Web Service"**
   - Connectez votre repo GitHub
   - Sélectionnez `YOUCAISSEPRO-RENDER`

---

## ⚙️ ETAPE 4 : Configurer le Web Service

### Configuration générale :
```
Name: you-caisse-pro
Region: Frankfurt
Runtime: Docker
Plan: Free
```

### Variables d'environnement :
```
NODE_ENV = production
PORT = 10000
DATABASE_URL = postgresql://[votre-URL-PostgreSQL]
JWT_SECRET = your-super-secret-key-change-this
PRINTER_ENABLED = false
```

### Docker :
- **Dockerfile Path:** `Dockerfile`
- **Build Command:** (laisser vide)
- **Start Command:** (laisser vide, utilise CMD du Dockerfile)

---

## ⏳ ETAPE 5 : Attendre le déploiement

1. Cliquez **"Create Web Service"**
2. **Attendez 5-10 minutes** le build Docker
3. Quand vous voyez **"Live"** (en vert) → C'est bon !

---

## ✨ ETAPE 6 : Tester l'application

1. Sur la page du service, copiez l'**URL public** 
   (ex: `https://you-caisse-pro-xxxxx.onrender.com`)

2. Ouvrez dans le navigateur

3. Connectez-vous :
   ```
   Username: admin
   Password: admin123
   ```

---

## 🔧 DÉPANNAGE

### Le service est en erreur ?
```
→ Allez dans "Logs"
→ Cherchez le message d'erreur
→ Vérifiez DATABASE_URL
→ Redéployez
```

### Base de données introuvable ?
```
→ Vérifiez que PostgreSQL est "Live"
→ Vérifiez DATABASE_URL
→ Lancez une migration si nécessaire
```

### Réapprovisionner ?
```
git push origin main
→ Render redéploiera automatiquement
```

---

## 📞 SUPPORT

Si vous avez des questions :
- Consultez les logs Render
- Vérifiez la configuration des env vars
- Vérifiez que PostgreSQL est actif
